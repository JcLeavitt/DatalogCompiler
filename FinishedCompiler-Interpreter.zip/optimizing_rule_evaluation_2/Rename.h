#include <string>
#include <vector>
#include <iostream>
using namespace std;

class Rename : public vector<string>{};
