#ifndef OLD_MAIN_H
#define OLD_MAIN_H
#include "Token.h"
#include <vector>
#include <queue>

std::vector <Token *> analyzer_tokens(string input_file);

#endif
